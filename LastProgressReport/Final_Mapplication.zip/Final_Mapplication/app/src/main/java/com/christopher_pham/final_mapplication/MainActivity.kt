package com.christopher_pham.final_mapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.christopher_pham.final_mapplication.models.Place
import com.christopher_pham.final_mapplication.models.UserMap

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val userMaps = generateSampleData()
        //layout manager for map list
        val rvMaps = findViewById<RecyclerView>(R.id.rvMaps)
        rvMaps.layoutManager = LinearLayoutManager(this)
        //adapter on map list
        rvMaps.adapter = MapsAdapter(this, userMaps)
    }

    private fun generateSampleData(): List<UserMap> {
        return listOf(
            UserMap("Hiking Trails",
                listOf(
                    Place("Chauncy Lake", "A hiking trail that goes around Chauncy Lake", 42.2987411, -71.6111210)
                )
            ),
            UserMap("University of Massachusetts Lowell",
                listOf(
                    Place("Dandeneau Hall", "I go to class here!", 42.6532967, -71.3249008)
                )
            ),
            UserMap("Mountains",
                listOf(
                    Place("Mt. Washington", "The tallest mountain in New Hampshire", 44.2705854, -71.3032723)
                )
            )
        )


    }


}