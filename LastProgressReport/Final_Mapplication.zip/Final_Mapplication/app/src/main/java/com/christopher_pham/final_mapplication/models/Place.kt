package com.christopher_pham.final_mapplication.models

data class Place(val title: String, val description: String, val latitude: Double, val longitude: Double) {

}