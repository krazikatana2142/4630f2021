package com.christopher_pham.final_mapplication.models

data class UserMap(val title: String, val places: List<Place>) {

}